# KH110 – KHITServices Primary Logo Lockup

KH Number: KH110  
Name: KHITServices Primary Logo Lockup  
Version: v0.1  
Status: Draft / Pending Final Assembly from Official Logo Source  
Asset Type: Logo Component  

## Purpose

Primary KHITServices corporate logo lockup for controlled use across brand assets.

## Composition

- Orange rounded rectangle outline
- Orange circle containing dark navy/blue hash
- KHITServices wordmark
- No strapline

## Usage

Website header, document covers, proposals, reports, social banners, device wallpapers, presentation templates and other formal KHITServices brand applications.

## Do Not Use

- Do not include the strapline inside KH110.
- Do not recreate or redraw the logo for production.
- Do not use provisional placeholder artwork as approved production artwork.
- Do not stretch, distort or recolour outside approved rules.

## Dependencies

- Official KHITServices logo pack
- BR001 – Brand Identity Manual
- KH000 – Project Context & Working Principles
- KHAL controlled asset rules

## File Formats

Expected final formats:
- SVG master
- Transparent PNG
- PDF/EPS if available from designer source

Current v0.1 files:
- Draft placeholder SVG only
- Visual reference retained separately

## Revision History

- v0.1 – Controlled component record created. Placeholder structure created pending final logo assembly from official source files.

## Approval Status

Pending final approved logo source.
