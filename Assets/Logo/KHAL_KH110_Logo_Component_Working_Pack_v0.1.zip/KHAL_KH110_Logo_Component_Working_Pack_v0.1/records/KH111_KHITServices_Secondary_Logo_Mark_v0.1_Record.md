# KH111 – KHITServices Secondary Logo Mark

KH Number: KH111  
Name: KHITServices Secondary Logo Mark  
Version: v0.1  
Status: Draft / Pending Final Assembly from Official Logo Source  
Asset Type: Logo Component  

## Purpose

Short-form KHITServices brand mark for use where the full wordmark is not practical.

## Composition

- Orange circle
- Dark navy/blue hash only
- No wordmark
- No rounded rectangle
- No strapline
- No background

## Usage

Profile avatars, favicons, app marks, icons, small social placements, watermark/detail usage and compact brand placements.

## Do Not Use

- Do not use as a replacement for KH110 where the full primary lockup is required.
- Do not include strapline or wordmark.
- Do not recreate or redraw for production.
- Do not use provisional placeholder artwork as approved production artwork.

## Dependencies

- Official KHITServices logo pack
- BR001 – Brand Identity Manual
- KH000 – Project Context & Working Principles
- KHAL controlled asset rules

## File Formats

Expected final formats:
- SVG master
- Transparent PNG
- ICO/favicon set where required
- App icon sizes where required

Current v0.1 files:
- Draft placeholder SVG only

## Revision History

- v0.1 – Controlled component record created. Placeholder structure created pending final logo assembly from official source files.

## Approval Status

Pending final approved logo source.
