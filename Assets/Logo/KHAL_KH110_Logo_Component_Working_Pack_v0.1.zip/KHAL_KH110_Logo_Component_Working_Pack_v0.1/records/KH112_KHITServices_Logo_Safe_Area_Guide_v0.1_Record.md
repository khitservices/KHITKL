# KH112 – KHITServices Logo Safe Area Guide

KH Number: KH112  
Name: KHITServices Logo Safe Area Guide  
Version: v0.1  
Status: Draft / Pending Final Logo Source  
Asset Type: Logo Usage Guide  

## Purpose

Defines placement, safe-area and minimum-spacing rules for KH110 and KH111 within KHAL assets.

## Usage

Used when compiling final assets including LinkedIn banners, website hero sections, document covers, wallpapers, presentation templates and application assets.

## Current Guidance

Until final vector logo files are confirmed:
- Keep generous clear space around the primary logo lockup.
- Do not place the logo directly over the large orange hash or dense data wave.
- Prefer upper-left or lower-left placement depending on layout.
- Use KH110 where the full brand name is required.
- Use KH111 only where compact placement is required.

## Dependencies

- KH110 – KHITServices Primary Logo Lockup
- KH111 – KHITServices Secondary Logo Mark
- BR001 – Brand Identity Manual
- KH000 – Project Context & Working Principles

## File Formats

- SVG guide
- Markdown record

## Revision History

- v0.1 – Initial safe-area guidance created pending final approved logo source.

## Approval Status

Draft.
