# KHAL Logo Component Register – KH110 to KH112

| KH Number | Name | Category | Version | Status | Notes |
|---|---|---:|---|---|---|
| KH110 | KHITServices Primary Logo Lockup | Logo Component | v0.1 | Draft / Pending Final Logo Source | Full lockup, no strapline |
| KH111 | KHITServices Secondary Logo Mark | Logo Component | v0.1 | Draft / Pending Final Logo Source | Orange circle + blue hash only |
| KH112 | KHITServices Logo Safe Area Guide | Logo Usage Guide | v0.1 | Draft | Placement and spacing guidance |
| KHM001 | Primary Brand Strapline | Messaging Component | v0.1 | Candidate | Separate from logo |

## Control Principle

The strapline is not part of KH110 or KH111. Strapline wording is controlled separately as a messaging component.

Base KHAL assets remain logo-free wherever possible. Final output assets compile the official logo source into the approved layout.
