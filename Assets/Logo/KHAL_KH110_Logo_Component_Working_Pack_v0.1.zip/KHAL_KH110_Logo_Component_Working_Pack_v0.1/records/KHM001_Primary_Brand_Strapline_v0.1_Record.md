# KHM001 – Primary Brand Strapline

Component Number: KHM001  
Name: Primary Brand Strapline  
Version: v0.1  
Status: Candidate / Pending Final Approval  
Component Type: Messaging Component  

## Approved / Candidate Wording

Your Service, Our Expertise.

## Purpose

Primary KHITServices strapline for use where additional brand positioning is required.

## Usage

Website hero sections, LinkedIn banners, document covers, proposal covers and presentation title slides where the strapline is intentionally included.

## Do Not Use

- Do not include inside KH110 or KH111.
- Do not treat as part of the logo.
- Do not alter punctuation, case or wording without controlled revision.

## Dependencies

- KH000 – Project Context & Working Principles
- BR001 – Brand Identity Manual
- KHAL controlled messaging rules

## Revision History

- v0.1 – Strapline separated from logo components and registered as controlled messaging component.

## Approval Status

Candidate / Pending approval.
