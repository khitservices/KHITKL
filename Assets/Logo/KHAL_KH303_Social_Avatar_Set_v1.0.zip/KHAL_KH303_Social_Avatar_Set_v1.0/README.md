# KHAL KH303 Social Avatar Set v1.0

This pack contains the approved KH303 social avatar family.

## Contents

- KH303A – Mark-Only Avatar
- KH303B – Named Avatar, Option A approved

## Rejected

- Option B
- Option C

## Repo Placement

Recommended path:

`KH300_Social_Assets/KH303_Social_Avatar_Set/`

with subfolders:

- `KH303A_Mark_Only_Avatar`
- `KH303B_Named_Avatar`
