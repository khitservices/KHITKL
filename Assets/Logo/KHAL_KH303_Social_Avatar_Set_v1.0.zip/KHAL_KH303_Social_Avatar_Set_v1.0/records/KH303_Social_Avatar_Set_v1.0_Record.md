# KH303 – Social Avatar Set

KH Number: KH303  
Name: Social Avatar Set  
Version: v1.0  
Status: Approved  
Category: KH300 Social Assets  

## Purpose

Controlled KHITServices avatar assets for social media and profile use.

## Asset Family

### KH303A – Mark-Only Avatar

Use where icon-only profile presentation is sufficient or where text will not be readable.

Built from:
- KH111 – Secondary Logo Mark

### KH303B – Named Avatar

Use where the avatar needs to carry the KHITServices name visibly, especially where the page banner should not repeat the logo.

Selected direction:
- Option A – stacked mark + KHITServices name

Built from:
- KH001 – Executive Background
- KH111 – Secondary Logo Mark
- KHITServices name text

## Rejected Options

- Option B – full KH110 wordmark inside square avatar
- Option C – name-heavy square

## Usage Rule

KH303A and KH303B are both part of KH303 Social Avatar Set.  
Do not create a separate top-level number for the named avatar.  
Do not use rejected options B or C.

## Recommended Use

- LinkedIn company avatar: KH303B Named Avatar
- Facebook profile avatar: KH303B Named Avatar
- Favicon/app compact icon: KH303A Mark-Only Avatar
- Small social icon spaces: KH303A Mark-Only Avatar

## Revision History

- v1.0 – Approved KH303 avatar family created with KH303A mark-only and KH303B named avatar Option A.
