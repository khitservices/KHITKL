# KHAL KH303 Avatar Register v1.0

| Asset | Name | Status | Use |
|---|---|---|---|
| KH303A | Mark-Only Avatar | Approved | Icon-only profile/avatar use |
| KH303B | Named Avatar | Approved | Profile/avatar use where KHITServices name should be visible |

## Control Notes

KH303B is Option A from the preview pack.  
Options B and C are rejected and must not be used.
