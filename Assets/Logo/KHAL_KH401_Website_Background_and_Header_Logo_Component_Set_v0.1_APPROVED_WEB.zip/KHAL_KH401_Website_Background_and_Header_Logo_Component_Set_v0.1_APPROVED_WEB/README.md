# KHAL KH401 Website Background and Header Logo Component Set v0.1 APPROVED WEB

Created: 2026-07-06

This pack adds the confirmed KHITServices web header logo and website background motif components to the repo library.

## Repo location

```text
KHITKL/Assets/Website/KHAL_KH401_Website_Background_and_Header_Logo_Component_Set_v0.1_APPROVED_WEB/
```

## Deployable assets

```text
assets/header_logo/KH401A_KHITServices_Web_Header_Logo_ON_DARK_v0.1_APPROVED_WEB_TRANSPARENT.png
assets/background_motifs/KH401B_KHITServices_Web_Swirl_Hero_Background_v0.1_APPROVED_WEB.png
assets/background_motifs/KH401B_KHITServices_Web_Swirl_Hero_Background_v0.1_APPROVED_WEB.webp
assets/logo_mark/KH401C_KHITServices_Web_Mark_Watermark_v0.1_APPROVED_WEB.png
assets/KH401_Website_Component_Styles_v0.1_APPROVED_WEB.css
```

## Repo control updates

```text
repo_update/KHAL_REPO_INDEX_UPDATE_v0.2_KH401.md
repo_update/KHAL_ASSET_REGISTER_UPDATE_v0.2_KH401.json
```
