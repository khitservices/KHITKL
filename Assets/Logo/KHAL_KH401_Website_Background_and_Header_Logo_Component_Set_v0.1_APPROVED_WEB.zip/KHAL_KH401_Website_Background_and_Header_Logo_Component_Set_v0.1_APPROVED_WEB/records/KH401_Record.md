# KHAL KH401 Website Background and Header Logo Component Set v0.1 APPROVED WEB

Date: 2026-07-06

## Status

**APPROVED WEB**

This pack adds the KHITServices website-specific header logo and website background motif components to the KHAL library.

## Assets

```text
KH401A_KHITServices_Web_Header_Logo_ON_DARK_v0.1_APPROVED_WEB_TRANSPARENT.png
KH401B_KHITServices_Web_Swirl_Hero_Background_v0.1_APPROVED_WEB.png
KH401B_KHITServices_Web_Swirl_Hero_Background_v0.1_APPROVED_WEB.webp
KH401C_KHITServices_Web_Mark_Watermark_v0.1_APPROVED_WEB.png
KH401_Website_Component_Styles_v0.1_APPROVED_WEB.css
```

## Usage

Use KH401A for dark/navy website headers.

Use KH401B as the approved website hero/background swirl component.

Use KH401C as the lower-page mark/watermark component.

## Important logo rule

Do **not** use the normal KH110 transparent full-colour logo on dark website backgrounds.  
It renders as navy/blue text on navy.

Use KH401A for the website dark header.

## Repo location

Recommended:

```text
KHITKL/Assets/Website/KHAL_KH401_Website_Background_and_Header_Logo_Component_Set_v0.1_APPROVED_WEB/
```
