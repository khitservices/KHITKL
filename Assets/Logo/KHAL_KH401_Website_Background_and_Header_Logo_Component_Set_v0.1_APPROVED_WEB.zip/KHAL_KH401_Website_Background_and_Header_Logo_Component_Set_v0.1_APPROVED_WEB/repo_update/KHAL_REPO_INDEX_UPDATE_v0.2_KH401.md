# KHAL Repo Index Update v0.2

Date: 2026-07-06

## Add to repo

```text
KHITKL/Assets/Website/KHAL_KH401_Website_Background_and_Header_Logo_Component_Set_v0.1_APPROVED_WEB/
```

## New approved web assets

| Item | Status | Repo location | Notes |
|---|---:|---|---|
| KH401A Web Header Logo ON DARK | Approved Web | Assets/Website/KHAL_KH401.../assets/header_logo/ | Correct website dark-header logo. Transparent PNG. No white box. |
| KH401B Web Swirl Hero Background | Approved Web | Assets/Website/KHAL_KH401.../assets/background_motifs/ | Derived from approved KH304 exec/wallpaper treatment. |
| KH401C Web Mark Watermark | Approved Web | Assets/Website/KHAL_KH401.../assets/logo_mark/ | Approved KH111 mark for website watermark/secondary placement. |

## Supersede / bin for website work

```text
KHITServices_homepage_rebuild_v0.1_CORRECT_LOGOS_WATERMARKS
KHITServices_homepage_rebuild_v0.2_CLEAN_BRAND
KHITServices_webpage_template_v0.3_EXEC_BRAND
KHITServices_webpage_template_v0.4_DARK_LOGO_FIXED
KHITServices_webpage_template_v0.5_WEB_REVERSED_LOGO
KHITServices_web_logo_transparent_reversed_v0.6
KHITServices_index_holding_page_v0.3_swirl_hash_background
KHITServices_index_holding_page_v0.4_APPROVED_ARTWORK_BACKGROUND
```

## New rule

For dark/navy website headers, use:

```text
KH401A_KHITServices_Web_Header_Logo_ON_DARK_v0.1_APPROVED_WEB_TRANSPARENT.png
```

Do not use the normal KH110 transparent full-colour logo on dark backgrounds.
