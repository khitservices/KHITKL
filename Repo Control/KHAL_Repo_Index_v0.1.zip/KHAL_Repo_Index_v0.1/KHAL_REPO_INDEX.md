# KHAL Repo Index v0.1

Status: **Current control index**  
Date: **2026-07-06**  
Owner: **KHITServices**

This index records what should be kept, parked, superseded or scrapped in the KHAL repository.

---

## Current repository structure

```text
KHITKL/
├── Assets/
│   └── Logo/
└── Templates/
```

---

## Golden rules

```text
Approved = repo-current and safe to use
Parked = keep out of live use; needs rethink
Superseded = old version replaced by newer version
Scrap / do not use = remove or archive outside live repo
```

Client-facing documents must follow the approved KH600 document standard.  
Internal trackers and working logs can use practical formats such as Excel and do not need formal DOCX standardisation.  
KHITView is internal to KHITServices. The client-facing entry point is the website Self-Healthcheck.

---

# 1. Assets / Logo

## Approved / keep

| Item | Status | Notes |
|---|---:|---|
| `KHAL_KH110_KH111_Approved_Logo_Pack_v1.1_CORRECTED.zip` | Approved | Correct KH110/KH111 logo pack. Use this as the logo source of truth. |
| `KHAL_KH301_KH302_KH305_KH309_Approved_Banner_Files_v1.1...zip` | Approved | Approved banner set. |
| `KHAL_KH303_Social_Avatar_Set_v1.0.zip` | Approved | Approved social avatar set. |
| `KHAL_KH304_Wallpaper_Set_v1.0_APPROVED.zip` | Approved | Approved wallpaper set. |
| `KHAL_KH306_LinkedIn_Post_Template_Set_v1.0_APPROVED_LOCKED...zip` | Approved | Approved LinkedIn post templates. |
| `KHAL_KH307_Facebook_Post_Template_Set_v1.0_APPROVED_SQUARE...zip` | Approved | Approved Facebook square post templates. |
| `KHAL_KH308_Instagram_Post_Template_Set_v1.0_APPROVED_SQUA...zip` | Approved | Approved Instagram square post templates. |
| `KHAL_KH310_Short_Form_Post_Template_Set_v1.0_APPROVED_REP...zip` | Approved | Approved short-form post templates. |
| `KHAL_KH311_Google_Ads_Display_Asset_Set_v0.1.zip` | Approved | Approved Google Ads display asset set. |
| `KHITServices.zip` | Approved / source archive | Keep as source logo/archive material if this is the original upload pack. |

## Working / historical / review

| Item | Status | Notes |
|---|---:|---|
| `KHAL_KH001_Working_Pack_v0.1.zip` | Working / historical | Keep only if still needed as background/source material. Not an approved live asset unless separately confirmed. |
| `KHAL_KH110_Logo_Component_Working_Pack_v0.1.zip` | Working / superseded | Superseded by approved KH110/KH111 corrected logo pack. Do not use as source of truth. |

## Remove / archive

| Item | Status | Notes |
|---|---:|---|
| `delete` | Remove | Placeholder/delete marker. Remove from live repo if not needed. |

---

# 2. Templates

## Approved / keep

| Item | Status | Notes |
|---|---:|---|
| `KHAL_KH312_PowerPoint_Template_v0.3_REPO_LIGHT.pptx` | Approved / current candidate | Current PowerPoint template candidate from approved v0.2 direction. |
| `KHAL_KH600_Document_Library_Standard_v0.6_APPROVED_KH110_...zip` | Approved | Current document library standard. Source of truth for client-facing DOCX style. |
| `KHAL_KH600_Document_Output_Style_Guide_Sheet_v0.1.pdf` | Approved / reference | Style guide sheet. Keep as reference. |
| `KHAL_KH601_Commercial_Document_Template_Set_v0.1.zip` | Approved | Commercial documents: invoice, quote, proposal/engagement letter, SOW. |
| `KHAL_KH601A_Invoice_Template_From_Existing_Invoice_v0.1.zip` | Approved | One-page invoice template based on existing KHITServices invoice layout. |
| `KHAL_KH602A_Project_Brief_Template_v1.0_APPROVED.zip` | Approved | Keep as the only retained KH602 DOCX delivery template. |
| `KHAL_KH605_Legal_Terms_Pack_v0.3_SOLICITOR_REVIEW_DRAFT_...zip` | Approved as solicitor-review draft | Correct legal review draft. Not for publication until solicitor approved. |

## Parked / rethink

| Item | Status | Notes |
|---|---:|---|
| `KHAL_KH320_Print_Collateral_Template_Set_v0.1.zip` | Parked | Business card/A5 flyer set parked for rethink. Do not upload as approved. |

## Scrapped / do not use

| Item | Status | Notes |
|---|---:|---|
| `KHAL_KH602_Delivery_Document_Template_Set_v0.1.zip` | Scrap except KH602A | Full delivery set scrapped. Only KH602A Project Brief is retained separately as v1.0 approved. |
| `KHAL_KH603_KHITView_Client_Output_Template_Set_v0.1.zip` | Scrap | KHITView outputs are not standalone DOCX templates. |
| `KHAL_KH603_KHITView_Output_Design_Brief_v0.1_FOR_CLAUDE_APP_BUILD.zip` | Scrap | Not needed; captured in Claude. |
| `KHAL_KH605_Legal_Terms_Pack_v0.1_SOLICITOR_REVIEW_DRAFT.zip` | Superseded / do not use | Superseded by KH605 v0.3. |
| `KHAL_KH605_Legal_Terms_Pack_v0.2_SOLICITOR_REVIEW_DRAFT_INTERNAL_KHITVIEW.zip` | Superseded / do not use | Superseded by KH605 v0.3. |

## Remove / archive

| Item | Status | Notes |
|---|---:|---|
| `template` | Remove | Placeholder folder/file. Remove if empty or not intentionally used. |

---

# 3. Current approved working set

```text
Assets/Logo/
- KHAL_KH110_KH111_Approved_Logo_Pack_v1.1_CORRECTED.zip
- KHAL_KH301_KH302_KH305_KH309_Approved_Banner_Files_v1.1...
- KHAL_KH303_Social_Avatar_Set_v1.0.zip
- KHAL_KH304_Wallpaper_Set_v1.0_APPROVED.zip
- KHAL_KH306_LinkedIn_Post_Template_Set_v1.0_APPROVED_LOCKED...
- KHAL_KH307_Facebook_Post_Template_Set_v1.0_APPROVED_SQUARE...
- KHAL_KH308_Instagram_Post_Template_Set_v1.0_APPROVED_SQUA...
- KHAL_KH310_Short_Form_Post_Template_Set_v1.0_APPROVED_REP...
- KHAL_KH311_Google_Ads_Display_Asset_Set_v0.1.zip

Templates/
- KHAL_KH312_PowerPoint_Template_v0.3_REPO_LIGHT.pptx
- KHAL_KH600_Document_Library_Standard_v0.6_APPROVED_KH110_...zip
- KHAL_KH600_Document_Output_Style_Guide_Sheet_v0.1.pdf
- KHAL_KH601_Commercial_Document_Template_Set_v0.1.zip
- KHAL_KH601A_Invoice_Template_From_Existing_Invoice_v0.1.zip
- KHAL_KH602A_Project_Brief_Template_v1.0_APPROVED.zip
- KHAL_KH605_Legal_Terms_Pack_v0.3_SOLICITOR_REVIEW_DRAFT_...zip
```

---

# 4. Commit message suggestions

## Assets / Logo

```text
Update approved KHAL logo and social asset register
```

## Templates

```text
Update approved KHAL template register
```

## Repo index

```text
Add KHAL repo index and approved asset register
```

---

# 5. Next housekeeping action

Create these index files at repo root or inside a `_repo_control/` folder:

```text
KHAL_REPO_INDEX.md
KHAL_ASSET_REGISTER.json
KHAL_TEMPLATE_REGISTER.json
```

Recommended location:

```text
KHITKL/_repo_control/
```
