# KHAL Repo Control Files v0.1

Use these files to control what is live in the KHITKL repo.

## Files

- `KHAL_REPO_INDEX.md`
- `KHAL_ASSET_REGISTER.json`
- `KHAL_TEMPLATE_REGISTER.json`

## Recommended repo location

```text
KHITKL/_repo_control/
```

## Status

Created: 2026-07-06

This is a repo-control aid, not a brand asset.
