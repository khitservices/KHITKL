# KHAL KH600 Document Library Standard v0.6 APPROVED KH110 LOGO

Use this instead of v0.5.

Correction:
- Replaced the cover logo with the approved KH110 primary logo lockup from:
  `khal_refs/logo/KHAL_KH110_KH111_Approved_Logo_Pack_v1.1_CORRECTED/assets/KH110_Primary_Logo_Lockup/KH110_KHITServices_Primary_Logo_Lockup_v1.0_FULL_COLOUR_ON_WHITE.png`

No other redesign.
