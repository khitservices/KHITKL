# KH601A Invoice Template - Existing Invoice Style v0.1

One-page invoice template based on the uploaded KHITServices invoice PDF layout.

## Rules applied
- Approved KH110 logo
- KHIT orange accent line and table header
- Clean one-page invoice layout
- Editable DOCX source
- PDF preview included
- Placeholder fields, not hard-coded client invoice data
