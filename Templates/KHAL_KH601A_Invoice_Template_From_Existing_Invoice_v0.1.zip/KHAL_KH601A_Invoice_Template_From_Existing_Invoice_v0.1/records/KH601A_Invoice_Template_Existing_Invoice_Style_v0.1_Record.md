# KH601A Invoice Template - Existing Invoice Style v0.1

## Status
Review draft.

## Source
KHITServices-Ltd_Invoice_007.pdf

## Built as
A one-page invoice-style DOCX template matching the uploaded invoice layout, but using controlled placeholder fields.

## Notes
This invoice-specific layout is intentionally lighter than the full KH600 formal document structure. It is suitable for invoices where a cover page, dynamic contents and Reference section would be unnecessary.
