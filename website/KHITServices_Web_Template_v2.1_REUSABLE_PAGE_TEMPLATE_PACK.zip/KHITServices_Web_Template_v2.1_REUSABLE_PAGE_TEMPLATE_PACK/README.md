# KHITServices reusable web template pack v2.1

Source: `KHITServices_Web_Template_v2.0_HERO_COPY_FIXED`

## Approved base

Use `templates/base-layout.html` as the master shell.

It contains:
- approved KH401 header logo
- approved swirl hero system
- footer using KHIT mark only
- social links including Bluesky
- large hash watermark beginning below the hero
- no booking language for Briefing or Review
- Chat CTA pattern
- official service structure

## Service structure rule

Only present the offer as:

1. Healthcheck
2. Briefing
3. Review

Ongoing:
- Service Advisor = small teams
- Virtual SDM = growing businesses

Do not present Project, Pricing or Professional Services as part of the main service journey on these public service pages.

## Included starter pages

The `pages/` folder contains starter HTML files for:

- healthcheck.html
- briefing.html
- review.html
- service-advisor.html
- vsdm.html

These are not final copy; they are layout-safe starter pages that follow the approved structure.

## Template files

- `templates/base-layout.html`
- `templates/standard-page-template.html`
- `templates/service-page-template.html`

## Asset paths

The starter pages live one folder below the root, so they use `../assets/...`.

When moving pages to the site root, change paths back to `assets/...`.
