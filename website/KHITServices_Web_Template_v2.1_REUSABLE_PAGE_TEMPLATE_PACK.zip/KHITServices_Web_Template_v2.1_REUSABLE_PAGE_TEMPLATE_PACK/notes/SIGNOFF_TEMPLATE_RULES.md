# Sign-off template rules

- Header: full KHITServices logo only.
- Footer: KHIT mark only.
- Hero: keep swirl treatment.
- Hero top copy on home page: "See your service clearly."
- Strapline: "Your Service, Our Expertise." remains official KHITServices strapline but should not crowd the home hero.
- Main services: Healthcheck, Briefing, Review.
- Ongoing: Service Advisor for small teams, Virtual SDM for growing businesses.
- No booking CTA for Briefing or Review via the website.
- Use Chat CTA where conversation is needed.
- Social links include LinkedIn, Facebook, Bluesky, Instagram and email.
