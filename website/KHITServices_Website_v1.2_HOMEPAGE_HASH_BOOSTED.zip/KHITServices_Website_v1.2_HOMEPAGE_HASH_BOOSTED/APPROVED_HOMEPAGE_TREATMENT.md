# KHITServices Website v1.1 — Homepage Swirl + Hash Approved

This package promotes the accepted v1.6 homepage visual treatment for use.

Accepted visual treatment:
- subtle full-page swirl background on homepage
- smaller single KHIT hash watermark
- no duplicate hash watermark
- no fixed viewport-following watermark
- transparent sections
- readable translucent cards
- tightened first-section spacing

Applied:
- index.html
- assets/css/site.css

Protected KHITView-linked files retained in package and not intentionally modified by this approval step:
- health-check.html
- health-check-results.html
- chat.html
- briefing-book.html
- review-book.html


Deployment note:
- This package includes the full site folder for convenience.
- The approved visual treatment is scoped to the homepage by the `full-swirl-preview` body class.
- Functional KHITView pages should still be regression tested before production deployment, but this packaging step does not change them.


Update v1.2:
- Increased visibility of the single hash watermark in the first (hero) section only by raising its opacity and vertical position.
- Slightly lightened the top overlay to allow the hero watermark to read more clearly without reintroducing duplicate watermark layers.
