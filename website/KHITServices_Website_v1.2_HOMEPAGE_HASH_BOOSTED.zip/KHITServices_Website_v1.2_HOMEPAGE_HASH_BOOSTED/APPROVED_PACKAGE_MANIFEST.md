# Package Manifest

- `index.html` — sha256 `0520e1e29fbcb75e6cdecf5839d435b30cb7d9e5346ffa8803fc5f73620e046d`
- `assets/css/site.css` — sha256 `3fafb13799bf4ebe9f753e60fb2214656f8d94842f03647d2a04e352fd8accaa`
- `assets/img/khitservices-swirl-bg.webp` — sha256 `efa954e4cd276edf2185e1b06d344beb254841483314fd0dbe75b3762c9cc397`
- `assets/img/khitservices-mark.png` — sha256 `d5fe921a094907ab08812a6f80c7288cb6c168c8581cb405a5527e465808f0d1`