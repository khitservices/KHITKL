# KHITView Integration Preservation

This v0.4 package was rebuilt from v0.2 to avoid carrying forward the v0.3 overwrite of functional pages.

## Preserved functional areas

The following pages must be regression tested because they contain or depend on booking, form, storage, API or redirect logic:

- health-check.html
- health-check-results.html
- chat.html
- briefing-book.html
- review-book.html

## Preservation rule

Do not alter:
- form IDs
- input names
- JavaScript submit handlers
- localStorage/sessionStorage keys
- API endpoints
- redirect/payment logic
- hidden fields used by KHITView reconciliation

## Commercial correction applied

- Healthcheck: free, user-led, optional.
- Briefing: chargeable for both tiers.
- Review: optional for growing businesses only.
- Service Advisor: optional for small teams post-Briefing and/or after improvement activity.
- Virtual SDM: optional for growing businesses after Review and/or after improvement actions are identified.


## v0.5 update

Only the static/commercial content pages were updated:
- pricing.html
- vsdm.html
- ongoing.html

No structural rewrite was applied to KHITView-linked functional pages.


## v0.6 update

Only public/static commercial pages were updated:
- briefing.html
- review.html
- service-advisor.html
- vsdm.html
- pricing.html
- ongoing.html

KHITView-linked functional pages were not structurally rewritten.


## v0.7 update

Only public/static content pages were updated:
- briefing.html
- review.html
- vsdm.html
- pricing.html

KHITView-linked functional pages were not structurally rewritten.


## v0.9 update

This build restores KHITView safety by rebuilding from v0.7.

Protected pages left byte-for-byte unchanged from v0.7:
- briefing-book.html: UNCHANGED
- chat.html: UNCHANGED
- health-check-results.html: UNCHANGED
- health-check.html: UNCHANGED
- review-book.html: UNCHANGED

No structural rewrite was applied to the protected KHITView-linked pages.


## v1.0 update

Rebuilt from v0.9 and protected KHITView-linked pages.

Protected page status:
- briefing-book.html: UNCHANGED
- chat.html: UNCHANGED
- health-check-results.html: UNCHANGED
- health-check.html: UNCHANGED
- review-book.html: UNCHANGED

No structural rewrite was applied to the protected KHITView-linked pages.
