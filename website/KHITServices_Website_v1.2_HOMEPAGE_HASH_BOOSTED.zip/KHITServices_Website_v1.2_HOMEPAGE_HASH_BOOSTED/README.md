# KHITServices Site Migrated v0.4

This package corrects the commercial logic and restores the pricing structure.

## Correct rules

- Healthcheck: free, user-led, optional.
- Briefing: chargeable for both tiers.
  - Small teams: £195
  - Growing businesses: £295
- Review: optional for growing businesses only.
  - £495-£1,495
  - £295 Briefing fee deducted from Review
- Service Advisor: optional for small teams post-Briefing and/or after improvement activity.
  - £45/mo or £499/yr
- Virtual SDM: optional for growing businesses after Review and/or after improvement actions are identified.
  - £500/day

## Notes

- Rebuilt from v0.2 to avoid carrying forward the v0.3 functional-page overwrite.
- KHITView-linked pages are preserved for regression testing.
- Swirl and hash brand treatment retained.


## v0.5 update — VSDM value comparison

Added the Virtual SDM value comparison to:
- pricing.html
- vsdm.html
- ongoing.html

The comparison positions Virtual SDM as fractional Service Management capacity for growing businesses, compared with the annual cost and commitment of employing a full-time Service Delivery Manager.

VSDM pricing model:
- £500/day: full day or split across the month.
- Extra time: £250 per half-day.
- £750/month: includes one onsite day plus the same Virtual SDM offering.
- Extra time above the £750 month: £250 per half-day.


## v0.6 update — client-led outputs and refined public pricing

- Removed public pricing from Service Advisor and Virtual SDM pages.
- Briefing and Review pricing remains visible.
- Pricing page now shows Service Advisor and Virtual SDM as follow-on assurance options discussed after the output is understood.
- Added output route messaging:
  - fix it yourself
  - engage someone else
  - engage KHITServices separately
  - add Service Advisor / Virtual SDM assurance where appropriate
- Reinforced client-led ethos: KHITServices advises, evidences and guides; the client decides.


## v0.7 update — VSDM value comparison and route fixes

- Restored VSDM value comparison on the Virtual SDM page.
- Added emphasis that growing businesses may need enterprise-level Service Management discipline without the cost and overhead of a full-time SDM.
- Corrected Briefing output routing:
  - Small teams: Service Advisor only where assurance is useful.
  - Growing businesses: Review route where greater depth is needed.
- Corrected Review output routing:
  - Review is growing-business only.
  - Virtual SDM is the only ongoing assurance option after Review.
- Pricing page now states:
  - Service Advisor discussed after Briefing.
  - Virtual SDM discussed after Review.


## v0.9 update — KHITView safe cleanup

- Rebuilt from v0.7 to restore health-check.html.
- Protected KHITView-linked pages left unchanged.
- Cleaned public-page wording without global text stripping.
- Contact section added to homepage.


## v1.0 update — document-aligned tightening

- Public pages rewritten against KM001, EG001, BS001, BR001 and CS001 principles.
- Service definitions tightened.
- Client-facing language made more professional and less lightweight.
- Spacing between hero/CTA areas and following sections reduced.
- Protected KHITView-linked pages left unchanged.
