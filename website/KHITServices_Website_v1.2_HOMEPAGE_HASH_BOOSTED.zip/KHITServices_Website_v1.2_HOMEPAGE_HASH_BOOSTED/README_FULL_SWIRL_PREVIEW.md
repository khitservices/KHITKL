# KHITServices Homepage v1.6 Smaller Hash + Lighter Watermarks

Based on v1.5.

Adjusted:
- First section spacing reduced.
- Hash made smaller.
- Hash visibility increased slightly.
- Swirl visibility increased by reducing the navy overlay.
- Cards made a little more transparent.
- Still one hash only.
- Still no fixed viewport-following watermark.
