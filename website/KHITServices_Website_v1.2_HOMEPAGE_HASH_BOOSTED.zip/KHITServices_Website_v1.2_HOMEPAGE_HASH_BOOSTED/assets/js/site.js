document.addEventListener('DOMContentLoaded', function () {
  const header = document.querySelector('.site-header');
  const toggle = document.querySelector('.nav-toggle');
  if (header && toggle) {
    toggle.addEventListener('click', function () {
      header.classList.toggle('is-open');
      this.setAttribute('aria-expanded', header.classList.contains('is-open') ? 'true' : 'false');
    });
  }
});
